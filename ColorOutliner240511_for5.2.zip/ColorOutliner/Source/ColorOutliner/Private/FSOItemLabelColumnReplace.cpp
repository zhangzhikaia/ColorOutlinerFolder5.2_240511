// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#include "FSOItemLabelColumnReplace.h"

#include "ActorFolderTreeItem.h"
#include "ActorTreeItem.h"
#include "ColorOutlinerUtils.h"
#include "SceneOutlinerItemLabelColumn.h"
#include "Widgets/Text/STextBlock.h"
#include "Widgets/SBoxPanel.h"
#include "Widgets/Layout/SBox.h"
#include "Widgets/Views/STableRow.h"
#include "Widgets/SOverlay.h"
#include "Engine/GameViewportClient.h"
#include "Framework/Application/SlateApplication.h"
#include "Widgets/Images/SImage.h"
#include "Styling/AppStyle.h"
#include "Editor.h"
#include "ScopedTransaction.h"
#include "SceneOutlinerStandaloneTypes.h"
#include "ISceneOutlinerMode.h"
#include "Widgets/Views/SListView.h"
#include "SortHelper.h"
#include "Widgets/SToolTip.h"
#include "ColorOutlinerUtils.h"

#define LOCTEXT_NAMESPACE "FSOItemLabelColumnReplace"

FName FSOItemLabelColumnReplace::GetColumnID()
{
	return GetID();
}

SHeaderRow::FColumn::FArguments FSOItemLabelColumnReplace::ConstructHeaderRowColumn()
{
	return SHeaderRow::Column(GetColumnID())
		.FillWidth( 5.0f );
}

const TSharedRef<SWidget> FSOItemLabelColumnReplace::ConstructRowWidget(FSceneOutlinerTreeItemRef TreeItem,
	const STableRow<FSceneOutlinerTreeItemPtr>& Row)
{
	TSharedPtr<SWidget> ItemLableRowWidget;
	
	ISceneOutliner* Outliner = WeakSceneOutliner.Pin().Get();
	check(Outliner);
	
	ItemLableRowWidget = TreeItem->GenerateLabelWidget(*Outliner, Row);

	/*start set color*/
	namespace OFUtils = SceneOutlinerFolderUtils;
	/*Folder*/
	if(FActorFolderTreeItem* SelectedFolder = TreeItem->CastTo<FActorFolderTreeItem>())
	{
		const FString FullPath = OFUtils::GetFolderFullPath(SelectedFolder);
		
		const TOptional<FLinearColor> PathColor = OFUtils::GetIsTempMap()?
				OFUtils::GetColorByPathTemp(SelectedFolder->GetPath().ToString()) : OFUtils::GetColorByPath(FullPath,true);
		
		if(PathColor.IsSet())
		{
			if(!PathColor->Equals(OFUtils::GetOutlinerItemDefaultColor(true)))
			{
				OFUtils::SetIconColor(ItemLableRowWidget,PathColor.GetValue()/OFUtils::GetOutlinerItemDefaultColor(true));
			}
		}
	}
	/*Actor*/
	else if(FActorTreeItem* SelectedActor = TreeItem->CastTo<FActorTreeItem>())
	{
		const FString FullPath = OFUtils::GetActorFullPath(SelectedActor);
		
		const TOptional<FLinearColor> PathColor = OFUtils::IsActorInTempMap(FullPath)?
			OFUtils::GetColorByPathTemp(SelectedActor->GetGuid().ToString()) : OFUtils::GetColorByPath(FullPath,false);
		
		if(PathColor.IsSet())
		{
			if(!PathColor->Equals(OFUtils::GetOutlinerItemDefaultColor(false)))
			/*return folder color,for actor item,as same*/
			{
				OFUtils::SetIconColor(ItemLableRowWidget,PathColor.GetValue());
			}
		}
	}
	/*set color done*/
	
	return ItemLableRowWidget.ToSharedRef();
}

void FSOItemLabelColumnReplace::PopulateSearchStrings( const ISceneOutlinerTreeItem& Item, TArray< FString >& OutSearchStrings ) const
{
	OutSearchStrings.Add(Item.GetDisplayString());
}

void FSOItemLabelColumnReplace::SortItems(TArray<FSceneOutlinerTreeItemPtr>& OutItems, const EColumnSortMode::Type SortMode) const
{
	typedef FSceneOutlinerSortHelper<int32, SceneOutliner::FNumericStringWrapper> FSort;

	FSort()
		.Primary([this](const ISceneOutlinerTreeItem& Item){ return WeakSceneOutliner.Pin()->GetTypeSortPriority(Item); },			SortMode)
		.Secondary([](const ISceneOutlinerTreeItem& Item){ return SceneOutliner::FNumericStringWrapper(Item.GetDisplayString()); }, SortMode)
		.Sort(OutItems);
}

#undef LOCTEXT_NAMESPACE
