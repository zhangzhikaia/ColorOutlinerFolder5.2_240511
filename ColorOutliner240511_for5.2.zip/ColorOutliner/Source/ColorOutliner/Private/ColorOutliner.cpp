// Copyright lurongjiu. All Rights Reserved.Intended published in 2024.

#include "ColorOutliner.h"

#include "LevelEditor.h"
#include "SceneOutlinerModule.h"
#include "ColorOutlinerUtils.h"
#include "SceneOutlinerMenuContext.h"
#include "SSceneOutliner.h"
#include "ToolMenu.h"
#include "ToolMenuDelegates.h"
#include "ToolMenuEntry.h"
#include "ToolMenuSection.h"
#include "ToolMenus.h"
#include "Widgets/Colors/SColorPicker.h"
#include "ActorFolderTreeItem.h"
#include "ActorTreeItem.h"
#include "FSOItemLabelColumnReplace.h"
#include "SOutlinerTreeView.h"
#include "SceneOutlinerItemLabelColumn.h"
#include "Editor.h"
#include "EditorActorFolders.h"
#include "EditorLevelUtils.h"
#include "Subsystems/EditorActorSubsystem.h"

#define LOCTEXT_NAMESPACE "FColorOutlinerModule"

namespace OFUtils = SceneOutlinerFolderUtils;

void FColorOutlinerModule::StartupModule()
{
	RegisterOnMapRename();
	RegisterOnMapDeleted();
	RegisterOnMapChanged();
	RegisterOnFolderOperate();
	RegisterOnActorDelete();
	RegisterOnMoveActorsToLevel();
	RegisterOutlinerItemLabelColumn();
	RegisterOutlinerContextMenuExtend();
}

void FColorOutlinerModule::ShutdownModule()
{
	/*UnregisterOnMapRename*/
	if(OnPreWorldRenameHandle.IsValid()){FWorldDelegates::OnPreWorldRename.Remove(OnPreWorldRenameHandle);}
	if(OnPostWorldRenameHandle.IsValid()){FWorldDelegates::OnPostWorldRename.Remove(OnPostWorldRenameHandle);}
	
	/*UnregisterOnMapDeleted*/
	if(OnAssetsPreDeleteHandle.IsValid()){FEditorDelegates::OnAssetsPreDelete.Remove(OnAssetsPreDeleteHandle);}
	if(OnAssetsDeletedHandle.IsValid()){FEditorDelegates::OnAssetsDeleted.Remove(OnAssetsDeletedHandle);}
	
	/*UnregisterOnMapChanged*/
	FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>(TEXT("LevelEditor"));
	if(OnMapChangedHandle.IsValid()){LevelEditorModule.OnMapChanged().Remove(OnMapChangedHandle);}
	
	/*UnregisterOnFolderOperate*/
	if(OnFolderMovedHandle.IsValid()){FActorFolders::OnFolderMoved.Remove(OnFolderMovedHandle);}
	if(OnFolderDeletedHandle.IsValid()){FActorFolders::OnFolderDeleted.Remove(OnFolderDeletedHandle);}

	if(OnLevelActorDeleted.IsValid()){
		if(GEngine!=nullptr){
			GEngine->OnLevelActorDeleted().Remove(OnLevelActorDeleted);}}

	if(OnMoveActorsToLevel.IsValid()){UEditorLevelUtils::OnMoveActorsToLevelEvent.Remove(OnMoveActorsToLevel);}
	
	/*UnregisterOutlinerItemLabelColumn*/
	FSceneOutlinerModule& SceneOutlinerModule = FModuleManager::LoadModuleChecked<FSceneOutlinerModule>(TEXT("SceneOutliner"));
	SceneOutlinerModule.UnRegisterColumnType<FSOItemLabelColumnReplace>();

	OFUtils::ClearCache();
}

void FColorOutlinerModule::RegisterOnMapRename()
{
	OnPreWorldRenameHandle = FWorldDelegates::OnPreWorldRename.AddLambda([](UWorld* World, const TCHAR* InName, UObject* NewOuter, ERenameFlags Flags, bool& bShouldFailRename)
	{
		OFUtils::OnPreWorldRename(World);
	});

	OnPostWorldRenameHandle = FWorldDelegates::OnPostWorldRename.AddLambda([](UWorld* World)
	{
		OFUtils::OnPostWorldRename(World);
	});
}

void FColorOutlinerModule::RegisterOnMapDeleted()
{
	OnAssetsPreDeleteHandle = FEditorDelegates::OnAssetsPreDelete.AddLambda([](const TArray<UObject*>& Objects)
	{
		OFUtils::OnWorldPreDelete(Objects);
	});
	
	OnAssetsDeletedHandle = FEditorDelegates::OnAssetsDeleted.AddLambda([](const TArray<UClass*>& Classes)
	{
		OFUtils::OnWorldDeleted();
	});
}

void FColorOutlinerModule::RegisterOnMapChanged()
{
	FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>(TEXT("LevelEditor"));
	
	OnMapChangedHandle = LevelEditorModule.OnMapChanged().AddLambda([&](UWorld* World, EMapChangeType MapChangeType)
	{
		FString NowMapPath;
		switch (MapChangeType)
		{
			case EMapChangeType::LoadMap:
				/*Template or existing*/
				NowMapPath = World->GetPathName();
				if(NowMapPath.StartsWith(TEXT("/Temp"),ESearchCase::CaseSensitive))
				{
					OFUtils::SaveIsTempMap(true);
				}
				else
				{
					OFUtils::SaveIsTempMap(false);
					NowMapPath.RemoveFromEnd(TEXT(".")+World->GetMapName());
					OFUtils::SaveCurrentMapPath(NowMapPath);
				}
			break;
		
			case EMapChangeType::NewMap:
				/*Empty level*/
				OFUtils::SaveIsTempMap(true);
			break;
		
			case EMapChangeType::SaveMap:
				/*Is template or empty level to save?*/
				if(OFUtils::GetIsTempMap())
				{
					OFUtils::TempToSave(World);
				}
			break;
		
			case EMapChangeType::TearDownWorld:
				/*Clear cache*/
				OFUtils::SaveCurrentMapPath(FString());
				OFUtils::ClearColorsTemp();
			break;
		}
	});
}

void FColorOutlinerModule::RegisterOnFolderOperate()
{
	OnFolderMovedHandle = FActorFolders::OnFolderMoved.AddLambda([](UWorld& World, const FFolder& Source, const FFolder& Dest)
	{
		OFUtils::SaveIsFolderMoved(true);
		OFUtils::UpdateFolderFullPath(Source,Dest);
	});
	
	OnFolderDeletedHandle = FActorFolders::OnFolderDeleted.AddLambda([]( UWorld& World, const FFolder& DeletedFolder )
	{
		if(!OFUtils::GetIsFolderMoved())
		{
			/*Not move,means delete*/
			OFUtils::DeleteFolderFullPath(DeletedFolder);
		}
		else
		{
			OFUtils::SaveIsFolderMoved(false);
		}
	});
}

void FColorOutlinerModule::RegisterOnActorDelete()
{
	if(GEngine==nullptr) return;
	OnLevelActorDeleted = GEngine->OnLevelActorDeleted().AddLambda([](AActor* ActorDeleted)
	{
		OFUtils::DeleteActorFullPath(ActorDeleted);
	});
}

void FColorOutlinerModule::RegisterOnMoveActorsToLevel()
{
	/*
	 *When executing the movement of Actors to another streaming level,
	 *the actual process involves deleting the original actors and regenerating identical actors in the new level.
	 *However, the Guids of the new actors will be refreshed.
	 */
	OnMoveActorsToLevel = UEditorLevelUtils::OnMoveActorsToLevelEvent.AddLambda([](const TArray<AActor*>& ActorsToDelete, const ULevel* DestLevel)
	{
		for(AActor* CurrentActorToDelete : ActorsToDelete)
		{
			if(CurrentActorToDelete==nullptr) continue;
			/*
			 *Although they are not the same AActor objects programmatically, their properties need to be copied completely, such as Tags.
			 *Therefore, during the deletion process,the item's color information is saved into the Tags,
			 *and upon generation, it is retrieved and the saved Tag is removed.
			 */
			const FString FullPath = OFUtils::GetActorFullPath(CurrentActorToDelete);
			
			TOptional<FLinearColor> TColor = OFUtils::IsActorInTempMap(FullPath)?
				OFUtils::GetColorByPathTemp(CurrentActorToDelete->GetActorGuid().ToString()) : OFUtils::GetColorByPath(FullPath,false);
			
			if(TColor.IsSet())
			{
				if(TColor.GetValue()!=OFUtils::GetOutlinerItemDefaultColor(false))
				{
					FName FNColor = FName(FString(TColor->ToString()));
					
					CurrentActorToDelete->Tags.AddUnique(FName(OFUtils::GetSectionName()));
					CurrentActorToDelete->Tags.AddUnique(FNColor);
					/*
					 * There is no need to explicitly perform a cleanup operation on the config,
					 * as the OnMoveActorsToLevelEvent automatically triggers a OnActorDeleted callback.
					 */
				}
			}
		}
		/*
		 * The retrieval process must be delayed for one frame since the actor accessed in the current frame is still the original one,
		 * and any operations performed on it will be carried out before destruction.
		 * After a frame delay, the Tags will be read, and the color information will be saved to the configuration.
		 */
		FTimerManager& TimerManager = DestLevel->GetWorld()->GetTimerManager();
		TimerManager.SetTimerForNextTick(
			FTimerDelegate::CreateLambda([]()
			{
				TArray<AActor*> ActorsToAdd= GEditor->GetEditorSubsystem<UEditorActorSubsystem>()->GetSelectedLevelActors();
				for(AActor* CurrentActorToAdd : ActorsToAdd)
				{
					if(CurrentActorToAdd==nullptr) continue;
					
					int FindIndex;
					if(CurrentActorToAdd->Tags.Find(FName(OFUtils::GetSectionName()),FindIndex))
					{
						if(FindIndex+2 == CurrentActorToAdd->Tags.Num())
						{
							FLinearColor FLColor;
							FLColor.InitFromString(CurrentActorToAdd->Tags[FindIndex+1].ToString());

							const FString FullPath = OFUtils::GetActorFullPath(CurrentActorToAdd);
							
							OFUtils::IsActorInTempMap(FullPath)?
								OFUtils::SaveColorWithPathTemp(CurrentActorToAdd->GetActorGuid().ToString(),FLColor,false):
								OFUtils::SaveColorWithPath(FullPath,FLColor,false);
							
							CurrentActorToAdd->Tags.SetNum(FindIndex);
						}
					}
				}
			})
		);
	});
}

void FColorOutlinerModule::RegisterOutlinerItemLabelColumn()
{
	FSceneOutlinerModule& SceneOutlinerModule = FModuleManager::LoadModuleChecked<FSceneOutlinerModule>(TEXT("SceneOutliner"));
	SceneOutlinerModule.UnRegisterColumnType<FSceneOutlinerItemLabelColumn>();
	
	SceneOutlinerModule.RegisterDefaultColumnType<FSOItemLabelColumnReplace>(FSceneOutlinerColumnInfo(ESceneOutlinerColumnVisibility::Visible, 6));
}

void FColorOutlinerModule::RegisterOutlinerContextMenuExtend()
{
	UToolMenu* Menu = UToolMenus::Get()->ExtendMenu(OFUtils::GetDefaultContextBaseMenuName());
	
	Menu->AddDynamicSection("SetColorSection", FNewToolMenuDelegate::CreateLambda([this](UToolMenu* InMenu)
	{
		USceneOutlinerMenuContext* Context = InMenu->FindContext<USceneOutlinerMenuContext>();
		if (!Context)
		{
			return;
		}
		FToolMenuSection& Section = InMenu->FindOrAddSection("SceneOutlinerItemOptions");
		Section.Label = LOCTEXT("ItemOptionsLabel", "Item Options");
		
		SelectedSceneOutliner = Context->SceneOutliner;
		FLevelEditorModule& LevelEditorModule = FModuleManager::LoadModuleChecked<FLevelEditorModule>(TEXT("LevelEditor"));
		SceneOutliners = LevelEditorModule.GetFirstLevelEditor()->GetAllSceneOutliners();
		
		/*select and only select folder*/
		if (Context->NumSelectedItems > 0 && Context->NumSelectedFolders == Context->NumSelectedItems)
        {
			ExecuteItems = SelectedSceneOutliner.Pin()->GetSelectedItems();
			
			Section.AddMenuEntry(
				"OutlinerSetColor",
				LOCTEXT("OutlinerSetColor", "Set Color"),
				LOCTEXT("OutlinerSetColorTooltip", "Sets the color this folder should appear as."),
				FSlateIcon(FAppStyle::GetAppStyleSetName(), "Icons.Color"),
				FUIAction( FExecuteAction::CreateRaw( this, &FColorOutlinerModule::OutlinerFolderExecutePickColor ) )
				);
			bool bHasAnyItemSetColor = false;
			for(const FSceneOutlinerTreeItemPtr& Ttem : ExecuteItems)
			{
				if(FActorFolderTreeItem* SelectedFolder = Ttem->CastTo<FActorFolderTreeItem>())
				{
					const FString FullPath = OFUtils::GetFolderFullPath(SelectedFolder);
		
					const TOptional<FLinearColor> Color = OFUtils::GetIsTempMap()?
					OFUtils::GetColorByPathTemp(SelectedFolder->GetPath().ToString()) : OFUtils::GetColorByPath(FullPath,true);
					
					if (Color.IsSet())
					{
						if(!Color->Equals(OFUtils::GetOutlinerItemDefaultColor(true)))
						{
							bHasAnyItemSetColor = true;
							break;
						}
					}
				}
			}
			if(bHasAnyItemSetColor)
			{
				Section.AddMenuEntry(
					"OutlinerClearColor",
					LOCTEXT("OutlinerClearColor", "Clear Color"),
					LOCTEXT("OutlinerClearColorTooltip", "Resets the color this folder appears as."),
					FSlateIcon(),
					FUIAction(FExecuteAction::CreateRaw( this, &FColorOutlinerModule::OutlinerFolderExecuteResetColor ))
					);
			}
        }
		/*only select actors*/
		else if(Context->NumSelectedItems > 0 && Context->NumSelectedFolders == 0 && Context->NumWorldsSelected == 0)
		{
			ExecuteItems = SelectedSceneOutliner.Pin()->GetSelectedItems();
			
			Section.AddMenuEntry(
				"OutlinerSetColor",
				LOCTEXT("OutlinerSetColor", "Set Color"),
				LOCTEXT("OutlinerSetColorTooltip", "Sets the color this actor icon should appear as."),
				FSlateIcon(FAppStyle::GetAppStyleSetName(), "Icons.Color"),
				FUIAction( FExecuteAction::CreateRaw( this, &FColorOutlinerModule::OutlinerActorExecutePickColor ) )
				);
			bool bHasAnyItemSetColor = false;
			for(const FSceneOutlinerTreeItemPtr& Ttem : ExecuteItems)
			{
				if(FActorTreeItem* SelectedActor = Ttem->CastTo<FActorTreeItem>())
				{
					const FString FullPath = OFUtils::GetActorFullPath(SelectedActor);
		
					const TOptional<FLinearColor> Color = OFUtils::IsActorInTempMap(FullPath)?
					OFUtils::GetColorByPathTemp(SelectedActor->GetGuid().ToString()) : OFUtils::GetColorByPath(FullPath,false);
					
					if (Color.IsSet())
					{
						if(!Color->Equals(OFUtils::GetOutlinerItemDefaultColor(false)))
						/*return folder color,for actor item,as same*/
						{
							bHasAnyItemSetColor = true;
							break;
						}
					}
				}
			}
			if(bHasAnyItemSetColor)
			{
				Section.AddMenuEntry(
					"OutlinerClearColor",
					LOCTEXT("OutlinerClearColor", "Clear Color"),
					LOCTEXT("OutlinerClearColorTooltip", "Resets the color this actor icon appears as."),
					FSlateIcon(),
					FUIAction(FExecuteAction::CreateRaw( this, &FColorOutlinerModule::OutlinerActorExecuteResetColor ))
					);
			}
		}
		else
		{
			SceneOutliners.Empty();
			ExecuteItems.Empty();
		}
	}));
}

void FColorOutlinerModule::OutlinerFolderExecutePickColor()
{
	// Spawn a color picker, so the user can select which color they want
	FLinearColor InitialColor = OFUtils::GetOutlinerItemDefaultColor(true);
	
	// Make sure an color entry exists for all the paths, otherwise they won't update in realtime with the widget color
	for (const FSceneOutlinerTreeItemPtr& SelectedItem : ExecuteItems)
	{
		if(FActorFolderTreeItem* SelectedFolder = SelectedItem->CastTo<FActorFolderTreeItem>())
		{
			const FString FullPath = OFUtils::GetFolderFullPath(SelectedFolder);
            
			TOptional<FLinearColor> Color = OFUtils::GetIsTempMap()?
				OFUtils::GetColorByPathTemp(SelectedFolder->GetPath().ToString()) : OFUtils::GetColorByPath(FullPath,true);
			
			if (Color.IsSet())
			{
				if(!Color->Equals(InitialColor))
				{
					// Default the color to the first valid entry
					InitialColor = Color.GetValue();
					break;
				}
			}
		}
	}

	FColorPickerArgs PickerArgs = FColorPickerArgs(InitialColor, FOnLinearColorValueChanged::CreateRaw(this, &FColorOutlinerModule::OnLinearColorValueChanged,true));
	PickerArgs.bIsModal = false;
	//PickerArgs.ParentWidget = ParentContent.Pin();

	OpenColorPicker(PickerArgs);
}

void FColorOutlinerModule::OutlinerActorExecutePickColor()
{
	// Spawn a color picker, so the user can select which color they want
	FLinearColor InitialColor = OFUtils::GetOutlinerItemDefaultColor(false);
	
	// Make sure an color entry exists for all the paths, otherwise they won't update in realtime with the widget color
	for (const FSceneOutlinerTreeItemPtr& SelectedItem : ExecuteItems)
	{
		if(FActorTreeItem* SelectedActor = SelectedItem->CastTo<FActorTreeItem>())
		{
			const FString FullPath = OFUtils::GetActorFullPath(SelectedActor);
			
			const TOptional<FLinearColor> Color = OFUtils::IsActorInTempMap(FullPath)?
				OFUtils::GetColorByPathTemp(SelectedActor->GetGuid().ToString()) : OFUtils::GetColorByPath(FullPath,false);
			if (Color.IsSet())
			{
				if(!Color->Equals(OFUtils::GetOutlinerItemDefaultColor(false)))
				{
					// Default the color to the first valid entry
					InitialColor = Color.GetValue();
					break;
				}
			}
		}
	}

	FColorPickerArgs PickerArgs = FColorPickerArgs(InitialColor, FOnLinearColorValueChanged::CreateRaw(this, &FColorOutlinerModule::OnLinearColorValueChanged,false));
	PickerArgs.bIsModal = false;
	//PickerArgs.ParentWidget = ParentContent.Pin();

	OpenColorPicker(PickerArgs);
}

void FColorOutlinerModule::OnLinearColorValueChanged(const FLinearColor InColor,bool bIsFolder)
{
	bIsFolder ? OnFolderColorClicked(InColor) : OnActorColorClicked(InColor);
}

FReply FColorOutlinerModule::OnFolderColorClicked(const FLinearColor InColor)
{
	for(const FSceneOutlinerTreeItemPtr& SelectedItem : ExecuteItems)
	{
		if(FActorFolderTreeItem* SelectedFolder = SelectedItem->CastTo<FActorFolderTreeItem>())
		{
			OFUtils::GetIsTempMap()?
				OFUtils::SaveColorWithPathTemp(SelectedFolder->GetPath().ToString(),InColor,true):
				OFUtils::SaveColorWithPath(OFUtils::GetFolderFullPath(SelectedFolder),InColor,true);
		}
	}
	RefreshSceneOutliner();
	return FReply::Handled();
}

FReply FColorOutlinerModule::OnActorColorClicked(const FLinearColor InColor)
{
	for(const FSceneOutlinerTreeItemPtr& SelectedItem : ExecuteItems)
	{
		if(FActorTreeItem* SelectedActor = SelectedItem->CastTo<FActorTreeItem>())
		{
			const FString FullPath = OFUtils::GetActorFullPath(SelectedActor);
			
			OFUtils::IsActorInTempMap(FullPath)?
				OFUtils::SaveColorWithPathTemp(SelectedActor->GetGuid().ToString(),InColor,false):
				OFUtils::SaveColorWithPath(FullPath,InColor,false);
		}
	}
	RefreshSceneOutliner();
	return FReply::Handled();
}

void FColorOutlinerModule::OutlinerFolderExecuteResetColor()
{
	for(const FSceneOutlinerTreeItemPtr& Item : ExecuteItems)
	{
		if(FActorFolderTreeItem* SelectedFolder = Item->CastTo<FActorFolderTreeItem>())
		{
			OFUtils::GetIsTempMap()?
				OFUtils::DeleteFullPathFromTemp(SelectedFolder->GetPath().ToString()):
				OFUtils::DeleteFullPathFromConfig(OFUtils::GetFolderFullPath(SelectedFolder));
		}
	}
	RefreshSceneOutliner();
}

void FColorOutlinerModule::OutlinerActorExecuteResetColor()
{
	for(const FSceneOutlinerTreeItemPtr& Item : ExecuteItems)
	{
		if(FActorTreeItem* SelectedActor = Item->CastTo<FActorTreeItem>())
		{
			const FString FullPath = OFUtils::GetActorFullPath(SelectedActor);
			OFUtils::IsActorInTempMap(FullPath)?
				OFUtils::DeleteFullPathFromTemp(SelectedActor->GetGuid().ToString()):
				OFUtils::DeleteFullPathFromConfig(FullPath);
		}
	}
	RefreshSceneOutliner();
}

void FColorOutlinerModule::RefreshSceneOutliner()
{
	for(const TWeakPtr<ISceneOutliner>& Outliner : SceneOutliners)
	{
		if(Outliner.Pin().IsValid())
		{
			Outliner.Pin()->FullRefresh();
		}
	}
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FColorOutlinerModule, ColorOutliner)